onEvent("button3", "click", function( ) {
	setScreen("screen2");
});
onEvent("button5", "click", function( ) {
	setScreen("screen3");
});
onEvent("button8", "click", function( ) {
	setScreen("screen4");
});
onEvent("button11", "click", function( ) {
	setScreen("screen5");
});
onEvent("button14", "click", function( ) {
	setScreen("screen6");
});
onEvent("button21", "click", function( ) {
	setScreen("screen7");
});
onEvent("button18", "click", function( ) {
	setScreen("screen8");
});
onEvent("button15", "click", function( ) {
	open("https://anushreyasatish.whjr.site/");
});
onEvent("button4", "click", function( ) {
	playSound("assets/The-Miraculous-Rush.mp3", false);
});
onEvent("button2", "click", function( ) {
	stopSound("assets/The-Miraculous-Rush.mp3");
});
onEvent("button6", "click", function( ) {
	playSound("Music-(2).mp3", false);
});
onEvent("button7", "click", function( ) {
	stopSound("Music-(2).mp3");
});
onEvent("button9", "click", function( ) {
	playSound("assets/Adrienette-Dance-Melody.mp3", false);
});
onEvent("button10", "click", function( ) {
	stopSound("assets/Adrienette-Dance-Melody.mp3");
});
onEvent("button12", "click", function( ) {
	playSound("assets/Wall-between-us-melody.mp3", false);
});
onEvent("button13", "click", function( ) {
	stopSound("assets/Wall-between-us-melody.mp3");
});
onEvent("button19", "click", function( ) {
	playSound("assets/The-last-dance-melody.mp3", false);
});
onEvent("button20", "click", function( ) {
  stopSound("assets/The-last-dance-melody.mp3");
});
onEvent("button16", "click", function( ) {
	playSound("assets/In-the-rain-melody.mp3", false);
});
onEvent("button17", "click", function( ) {
	stopSound("assets/In-the-rain-melody.mp3");
});